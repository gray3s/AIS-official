# AIST-official

Official repository for the AI Sanity Test (AIST).

## Current artifact

- `AIST_20260608.txt`
- Version: 20260608
- License: CC BY 4.0

## Project control files

- `rules.txt` — project-specific ground-rules for executing the AIST prompts
- `scope.txt` — project-specific scope definitions for AIST execution

## Purpose

The AI Sanity Test evaluates whether an AI system can coherently evaluate its
own outputs, calibrate confidence, identify uncertainty, classify data,
distinguish accuracy from precision, and reason consistently about whether its
own responses are rational, logical, truthful, accurate, precise, and
appropriate.

## Repository contents

- `AIST_20260608.txt` — current AIST artifact
- `rules.txt` — execution rules
- `scope.txt` — scope model
- `LICENSE` — Creative Commons Attribution 4.0 International license summary/link
- `README.md` — repository overview
